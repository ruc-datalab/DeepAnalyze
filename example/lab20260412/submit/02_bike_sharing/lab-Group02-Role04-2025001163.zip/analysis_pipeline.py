from __future__ import annotations

import json
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd


BASE_DIR = Path(__file__).resolve().parent
FIG_DIR = BASE_DIR / "figures"
OUTPUT_DIR = BASE_DIR / "outputs"

WEATHER_LABELS = {
    1: "Clear / Good",
    2: "Cloudy / Mist",
    3: "Light Rain or Snow",
}

WORKDAY_LABELS = {
    0: "Non-working day",
    1: "Working day",
}

USER_COLORS = {
    "registered": "#1f77b4",
    "casual": "#ff7f0e",
}


def ensure_output_dirs() -> None:
    FIG_DIR.mkdir(exist_ok=True)
    OUTPUT_DIR.mkdir(exist_ok=True)


def load_data() -> tuple[pd.DataFrame, pd.DataFrame]:
    day = pd.read_csv(BASE_DIR / "day.csv", parse_dates=["dteday"])
    hour = pd.read_csv(BASE_DIR / "hour.csv", parse_dates=["dteday"])
    return day, hour


def build_hourly_profile(hour: pd.DataFrame) -> pd.DataFrame:
    hourly_profile = (
        hour.groupby(["workingday", "hr"])[["casual", "registered", "cnt"]]
        .mean()
        .reset_index()
    )

    fig, axes = plt.subplots(2, 1, figsize=(11, 8), sharex=True, constrained_layout=True)
    for ax, workingday in zip(axes, [1, 0]):
        subset = hourly_profile[hourly_profile["workingday"] == workingday]
        ax.plot(
            subset["hr"],
            subset["registered"],
            marker="o",
            linewidth=2.2,
            color=USER_COLORS["registered"],
            label="Registered users",
        )
        ax.plot(
            subset["hr"],
            subset["casual"],
            marker="o",
            linewidth=2.2,
            color=USER_COLORS["casual"],
            label="Casual users",
        )
        if workingday == 1:
            ax.axvspan(6.5, 8.5, color="#d8e7ff", alpha=0.75)
            ax.axvspan(16.5, 18.5, color="#d8e7ff", alpha=0.75)
            ax.text(7.5, ax.get_ylim()[1] * 0.92, "Commute peak", ha="center", fontsize=10)
            ax.text(17.5, ax.get_ylim()[1] * 0.92, "Commute peak", ha="center", fontsize=10)
        ax.set_title(WORKDAY_LABELS[workingday])
        ax.set_ylabel("Average rentals")
        ax.grid(alpha=0.25)
        ax.legend(loc="upper left")

    axes[-1].set_xlabel("Hour of day")
    fig.suptitle("Hourly demand profile by user type", fontsize=14)
    fig.savefig(FIG_DIR / "hourly_demand_profile.png", dpi=180)
    plt.close(fig)

    hourly_profile.to_csv(OUTPUT_DIR / "hourly_profile.csv", index=False)
    return hourly_profile


def build_workday_composition(hour: pd.DataFrame) -> pd.DataFrame:
    workday_hourly = (
        hour[hour["workingday"] == 1]
        .groupby("hr")[["casual", "registered", "cnt"]]
        .mean()
        .reset_index()
    )
    workday_hourly["registered_share"] = workday_hourly["registered"] / workday_hourly["cnt"]
    workday_hourly["casual_share"] = workday_hourly["casual"] / workday_hourly["cnt"]

    fig, ax = plt.subplots(figsize=(11, 4.8), constrained_layout=True)
    colors = [
        "#9cc0ff" if hr in {7, 8, 17, 18} else "#bfd1f2"
        for hr in workday_hourly["hr"]
    ]
    ax.bar(workday_hourly["hr"], workday_hourly["registered_share"], color=colors, width=0.8)
    ax.axhline(workday_hourly["registered_share"].mean(), color="#1f77b4", linestyle="--", linewidth=1.5)
    ax.set_ylim(0, 1)
    ax.set_xlabel("Hour of day")
    ax.set_ylabel("Registered share of total demand")
    ax.set_title("Working day demand is dominated by registered users")
    ax.grid(axis="y", alpha=0.25)
    ax.text(
        0.02,
        0.93,
        "Highlighted bars: 07:00-08:00 and 17:00-18:00",
        transform=ax.transAxes,
        fontsize=10,
    )
    fig.savefig(FIG_DIR / "workday_registered_share.png", dpi=180)
    plt.close(fig)

    workday_hourly.to_csv(OUTPUT_DIR / "workday_hourly_composition.csv", index=False)
    return workday_hourly


def build_weather_impact(day: pd.DataFrame) -> pd.DataFrame:
    weather_daily = (
        day[day["weathersit"].isin([1, 2, 3])]
        .groupby(["workingday", "weathersit"])[["casual", "registered", "cnt"]]
        .mean()
        .reset_index()
    )

    normalized_rows: list[dict[str, float | int | str]] = []
    for workingday in [0, 1]:
        subset = weather_daily[weather_daily["workingday"] == workingday].set_index("weathersit")
        baseline = subset.loc[1, ["casual", "registered", "cnt"]]
        for weather in [1, 2, 3]:
            row = {
                "workingday": workingday,
                "weathersit": weather,
                "weather_label": WEATHER_LABELS[weather],
            }
            for col in ["casual", "registered", "cnt"]:
                row[f"{col}_index"] = subset.loc[weather, col] / baseline[col]
            normalized_rows.append(row)

    normalized = pd.DataFrame(normalized_rows)

    fig, axes = plt.subplots(1, 2, figsize=(12, 4.8), sharey=True, constrained_layout=True)
    for ax, workingday in zip(axes, [0, 1]):
        subset = normalized[normalized["workingday"] == workingday]
        x = range(len(subset))
        ax.bar(
            [i - 0.18 for i in x],
            subset["registered_index"],
            width=0.36,
            color=USER_COLORS["registered"],
            label="Registered users",
        )
        ax.bar(
            [i + 0.18 for i in x],
            subset["casual_index"],
            width=0.36,
            color=USER_COLORS["casual"],
            label="Casual users",
        )
        ax.set_xticks(list(x))
        ax.set_xticklabels(subset["weather_label"], rotation=12)
        ax.set_title(WORKDAY_LABELS[workingday])
        ax.set_ylim(0, 1.1)
        ax.grid(axis="y", alpha=0.25)

    axes[0].set_ylabel("Relative demand (weather 1 = 1.0)")
    axes[0].legend(loc="upper right")
    fig.suptitle("Daily weather sensitivity by user type", fontsize=14)
    fig.savefig(FIG_DIR / "daily_weather_sensitivity.png", dpi=180)
    plt.close(fig)

    weather_daily.to_csv(OUTPUT_DIR / "daily_weather_means.csv", index=False)
    normalized.to_csv(OUTPUT_DIR / "daily_weather_index.csv", index=False)
    return normalized


def compute_summary_metrics(day: pd.DataFrame, hour: pd.DataFrame) -> dict[str, float | dict[str, float]]:
    work = hour[hour["workingday"] == 1]
    commute = work[work["hr"].isin([7, 8, 17, 18])]

    work_totals = work[["casual", "registered", "cnt"]].sum()
    commute_totals = commute[["casual", "registered", "cnt"]].sum()

    hourly_weather = (
        hour[hour["weathersit"].isin([1, 3])]
        .groupby(["workingday", "weathersit"])[["casual", "registered", "cnt"]]
        .mean()
    )
    daily_weather = (
        day[day["weathersit"].isin([1, 3])]
        .groupby(["workingday", "weathersit"])[["casual", "registered", "cnt"]]
        .mean()
    )

    metrics = {
        "workday_registered_share": round(work_totals["registered"] / work_totals["cnt"], 4),
        "commute_registered_share": round(
            commute_totals["registered"] / commute_totals["cnt"], 4
        ),
        "commute_share_of_registered_volume": round(
            commute_totals["registered"] / work_totals["registered"], 4
        ),
        "commute_share_of_casual_volume": round(
            commute_totals["casual"] / work_totals["casual"], 4
        ),
        "hourly_bad_weather_drop_workday": {
            "casual": round(
                1 - hourly_weather.loc[(1, 3), "casual"] / hourly_weather.loc[(1, 1), "casual"],
                4,
            ),
            "registered": round(
                1
                - hourly_weather.loc[(1, 3), "registered"]
                / hourly_weather.loc[(1, 1), "registered"],
                4,
            ),
        },
        "hourly_bad_weather_drop_non_workday": {
            "casual": round(
                1 - hourly_weather.loc[(0, 3), "casual"] / hourly_weather.loc[(0, 1), "casual"],
                4,
            ),
            "registered": round(
                1
                - hourly_weather.loc[(0, 3), "registered"]
                / hourly_weather.loc[(0, 1), "registered"],
                4,
            ),
        },
        "daily_bad_weather_drop_workday": {
            "casual": round(
                1 - daily_weather.loc[(1, 3), "casual"] / daily_weather.loc[(1, 1), "casual"],
                4,
            ),
            "registered": round(
                1
                - daily_weather.loc[(1, 3), "registered"]
                / daily_weather.loc[(1, 1), "registered"],
                4,
            ),
        },
        "daily_bad_weather_drop_non_workday": {
            "casual": round(
                1 - daily_weather.loc[(0, 3), "casual"] / daily_weather.loc[(0, 1), "casual"],
                4,
            ),
            "registered": round(
                1
                - daily_weather.loc[(0, 3), "registered"]
                / daily_weather.loc[(0, 1), "registered"],
                4,
            ),
        },
    }

    with open(OUTPUT_DIR / "summary_metrics.json", "w", encoding="utf-8") as file:
        json.dump(metrics, file, ensure_ascii=False, indent=2)

    return metrics


def main() -> None:
    ensure_output_dirs()
    day, hour = load_data()
    build_hourly_profile(hour)
    build_workday_composition(hour)
    build_weather_impact(day)
    compute_summary_metrics(day, hour)
    print(f"Saved figures to: {FIG_DIR}")
    print(f"Saved tables and metrics to: {OUTPUT_DIR}")


if __name__ == "__main__":
    main()
